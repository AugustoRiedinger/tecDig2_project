#ifndef _LOCAL_H_
#define _LOCAL_H_

#include "_libs.h"

void READ_TEMP(void);
void WRITE_SD(void);
char DECODE_TEMP(float tempFloat);

#endif // _LOCAL_H_
