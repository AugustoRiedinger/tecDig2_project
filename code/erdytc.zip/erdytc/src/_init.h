#ifndef _INIT_H_
#define _INIT_H_

#include "libs.h"

void INIT_ALL(void);

#endif // _INIT_H_
