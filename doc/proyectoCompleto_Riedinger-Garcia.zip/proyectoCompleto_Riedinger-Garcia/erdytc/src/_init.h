#ifndef LOCAL_H_
#define LOCAL_H_

#include "libs.h"

void INIT_ALL(void);

#endif // LOCAL_H_
