#ifndef _LIBS_H_
#define _LIBS_H_

#include "standar.h"
#include "_hardware.h"
#include "_lcd.h"
#include "_usart.h"
#include "_exti.h"
#include "_timers.h"

#endif // _LIBS_H_
