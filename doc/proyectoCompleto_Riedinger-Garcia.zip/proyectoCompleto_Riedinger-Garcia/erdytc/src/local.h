#ifndef LOCAL_H_
#define LOCAL_H_

#include "libs.h"

void TEMP_CODE(void);
void SERVO_1(void);
void SERVO_2(void);
void SD(void);

#endif // LOCAL_H_
