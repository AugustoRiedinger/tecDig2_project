#ifndef _TIMERS_H_
#define _TIMERS_H_

#include "standar.h"

void INIT_TIM3(uint32_t Freq);

#endif // _TIMERS_H_
