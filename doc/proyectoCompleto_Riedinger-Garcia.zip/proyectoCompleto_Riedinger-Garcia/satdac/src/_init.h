#ifndef _INIT_H_
#define _INIT_H_

/*Librerias a utilizar:*/
#include "_libs.h"

/*Inicializacion de todos los parametros del sistema:*/
void INIT_ALL(void);

#endif // _INIT_H_
