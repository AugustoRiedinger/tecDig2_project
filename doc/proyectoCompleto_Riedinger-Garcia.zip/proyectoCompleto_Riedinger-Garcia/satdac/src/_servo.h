#ifndef _SERVO_H_
#define _SERVO_H_

uint8_t  DE = 6;
uint8_t  elements = 100;

#endif // _SERVO_H_
